"""
Initialize the CLI package. This can remain empty or contain shared CLI utilities.
"""
