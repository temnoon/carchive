# carchive2/src/carchive2/core/config.py

from pydantic import BaseSettings, Field
from typing import Optional
import keyring

class Settings(BaseSettings):
    openai_api_key: Optional[str] = Field(default=None, env="OPENAI_API_KEY")
    anthropic_api_key: Optional[str] = Field(default=None, env="ANTHROPIC_API_KEY")
    ollama_url: str = Field(default="http://localhost:11434", env="OLLAMA_URL")
    embedding_provider: str = Field(default="ollama", env="EMBEDDING_PROVIDER")
    embedding_model_name: str = Field(default="nomic-embed-text", env="EMBEDDING_MODEL_NAME")
    embedding_dimensions: int = Field(default=768, env="EMBEDDING_DIMENSIONS")
    vision_model_name: str = Field(default="llama3.2-vision", env="VISION_MODEL_NAME")
    text_model_name: str = Field(default="llama3.2", env="TEXT_MODEL_NAME")
    db_user: str = "carchive_app"
    db_password: Optional[str] = Field(default=None, env="DB_PASS")
    db_host: str = "localhost"
    db_name: str = "carchive03_db"

    def build_database_url(self) -> str:
        password = keyring.get_password("carchive_app", "db_password") or self.db_password
        return f"postgresql://{self.db_user}:{password}@{self.db_host}/{self.db_name}"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

    def get_secure_value(self, key: str, default=None):
        attr_name = key.lower()
        try:
            secure = keyring.get_password("carchive2", key)
            return secure or getattr(self, attr_name, default)
        except Exception:
            return getattr(self, attr_name, default)

# Instantiate settings
settings = Settings()

# Backward compatibility assignments:
DATABASE_URL = settings.build_database_url()
OPENAI_API_KEY = settings.get_secure_value("OPENAI_API_KEY")
ANTHROPIC_API_KEY = settings.get_secure_value("ANTHROPIC_API_KEY")
OLLAMA_URL = settings.get_secure_value("OLLAMA_URL")
DEFAULT_EMBEDDING_PROVIDER = EMBEDDING_PROVIDER = settings.embedding_provider
DEFAULT_EMBEDDING_MODEL = EMBEDDING_MODEL_NAME = settings.embedding_model_name
DEFAULT_EMBEDDING_DIMENSIONS = EMBEDDING_DIMENSIONS = settings.embedding_dimensions
VISION_MODEL_NAME = settings.vision_model_name
TEXT_MODEL_NAME = settings.text_model_name
