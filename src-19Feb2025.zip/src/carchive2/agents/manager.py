# carchive2/src/carchive2/agents/manager.py

from carchive2.core.config import (
    OLLAMA_URL,
    EMBEDDING_PROVIDER,
    EMBEDDING_MODEL_NAME,
    EMBEDDING_DIMENSIONS,
    VISION_MODEL_NAME,
    TEXT_MODEL_NAME
)
from carchive2.agents.base import BaseAgent
from carchive2.agents.openai_agent import OpenAIAgent
from carchive2.agents.ollama_agent import OllamaAgent
from carchive2.agents.nomic_text_embed_agent import NomicTextEmbedAgent
from carchive2.agents.ollama_chat_agent import OllamaChatAgent

class AgentManager:
    def __init__(self):
        from carchive2.core.config import OPENAI_API_KEY
        self.openai_key = OPENAI_API_KEY or "sk-..."
        self.ollama_url = OLLAMA_URL  # Defaults to "http://localhost:11434"

    def get_agent(self, provider: str) -> BaseAgent:
        if provider == "openai":
            return OpenAIAgent(api_key=self.openai_key)
        elif provider == "ollama-nomic":
            return NomicTextEmbedAgent(
                base_url=self.ollama_url,
                model_name=EMBEDDING_MODEL_NAME,
                dimensions=EMBEDDING_DIMENSIONS
            )
        elif provider == "ollama-vision":
            return OllamaChatAgent(model_name=VISION_MODEL_NAME, base_url=self.ollama_url)
        elif provider == "ollama-text":
            return OllamaChatAgent(model_name=TEXT_MODEL_NAME, base_url=self.ollama_url)
        elif provider == "ollama":
            return OllamaAgent(
                model_name=EMBEDDING_MODEL_NAME,
                model_version="nomic-embed-text",  # Ensure this matches the default
                base_url=self.ollama_url
            )
        else:
            raise ValueError(f"Unknown provider: {provider}")
