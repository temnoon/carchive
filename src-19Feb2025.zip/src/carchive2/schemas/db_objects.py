# carchive2/schemas/db_objects.py
from pydantic import BaseModel
from typing import Optional, Union
from uuid import UUID
import datetime

class BaseDBModel(BaseModel):
    id: UUID
    class Config:
        orm_mode = True

class ConversationRead(BaseDBModel):
    title: Optional[str]
    created_at: datetime.datetime
    meta_info: Optional[dict] = None

class MessageRead(BaseDBModel):
    conversation_id: Optional[UUID] = None
    content: str
    created_at: datetime.datetime
    meta_info: Optional[dict] = None

class CollectionRead(BaseDBModel):
    name: str
    created_at: datetime.datetime
    meta_info: Optional[dict] = None

class ChunkRead(BaseDBModel):
    content: str
    position: int
    meta_info: Optional[dict] = None

# Newly added model for joined message and conversation info
class MessageWithConversationRead(BaseModel):
    message_id: UUID
    content: str
    conversation_id: UUID
    conversation_title: Optional[str]
    conversation_created_at: datetime.datetime

    class Config:
        orm_mode = True

# Union type for heterogeneous lists
DBObject = Union[ConversationRead, MessageRead, CollectionRead, ChunkRead]
