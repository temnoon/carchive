# carchive2/schemas/content_task.py
from pydantic import BaseModel
from typing import Optional

class ContentTaskRequest(BaseModel):
    target_id: str
    target_type: str  # e.g., "message" or "chunk"
    task: str         # e.g., "summary", "categorize"
    context: Optional[str] = None
    override: bool = False
