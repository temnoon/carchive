# carchive2/schemas/search.py
from pydantic import BaseModel
from typing import Optional, Dict, Any

class SearchCriteria(BaseModel):
    text_query: Optional[str] = None
    meta_filters: Optional[Dict[str, Any]] = None
    top_k: int = 10
