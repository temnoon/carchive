from typing import List
from carchive2.database.session import get_session
from carchive2.database.models import Conversation, Embedding, Collection, CollectionItem, Message

def search_conversations(query: str, limit: int = 10) -> List[Conversation]:
    """
    Simple substring search in conversation titles.
    """
    with get_session() as session:
        results = session.query(Conversation)\
                         .filter(Conversation.title.ilike(f"%{query}%"))\
                         .limit(limit)\
                         .all()
    return results

def vector_search(anchor_vector: List[float], top_k: int = 5) -> List[Embedding]:
    """
    Example pgvector similarity search, if you have the relevant index set up.
    """
    with get_session() as session:
        results = session.query(Embedding)\
                         .order_by(Embedding.vector.l2_distance(anchor_vector))\
                         .limit(top_k)\
                         .all()
    return results

def create_collection_from_vector(name: str, anchor_vector: List[float], top_k: int = 5):
    """
    Create a collection from the top_k vector results.
    """
    with get_session() as session:
        coll = Collection(name=name)
        session.add(coll)
        session.flush()

        top_embs = session.query(Embedding)\
                          .order_by(Embedding.vector.l2_distance(anchor_vector))\
                          .limit(top_k)\
                          .all()

        for emb in top_embs:
            item = CollectionItem(
                collection_id=coll.id,
                message_id=emb.parent_message_id,
                chunk_id=emb.parent_chunk_id,
                meta_info={"embedding_id": str(emb.id)}
            )
            session.add(item)

        session.commit()
        session.refresh(coll)
    return coll

def search_messages(query: str, limit: int = 10) -> List[Message]:
    """
    Search for messages that contain the given query text.
    """
    with get_session() as session:
        results = session.query(Message)\
                         .filter(Message.content.ilike(f"%{query}%"))\
                         .limit(limit)\
                         .all()
    return results
