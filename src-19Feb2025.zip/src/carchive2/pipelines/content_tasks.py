# carchive2/src/carchive2/pipelines/content_tasks.py
from typing import Optional
from carchive2.database.session import get_session
from carchive2.database.models import Message, AgentOutput
from carchive2.agents.ollama_content_agent import OllamaContentAgent

class ContentTaskManager:
    def __init__(self, provider: str = "ollama"):
        # Remove any support for OpenAI. Only "ollama" is accepted.
        if provider.lower() == "ollama":
            self.agent = OllamaContentAgent(model_name="llama3.2")
        else:
            raise ValueError(f"Unsupported content agent provider: {provider}. Only 'ollama' is supported.")

    def run_task_for_message(
        self,
        message_id: str,
        task: str,
        context: Optional[str] = None,
        prompt_template: Optional[str] = None,
        override: bool = False
    ):
        with get_session() as session:
            msg = session.query(Message).filter_by(id=message_id).first()
            if not msg:
                raise ValueError(f"Message {message_id} not found.")

            existing = session.query(AgentOutput).filter(
                AgentOutput.target_type == "message",
                AgentOutput.target_id == msg.id,
                AgentOutput.output_type == task
            ).first()

            if existing and not override:
                return existing

            output_text = self.agent.process_task(
                task=task, content=msg.content, context=context, prompt_template=prompt_template
            )

            if existing and override:
                existing.content = output_text
                session.commit()
                session.refresh(existing)
                return existing

            agent_output = AgentOutput(
                target_type="message",
                target_id=msg.id,
                output_type=task,
                content=output_text,
                agent_name=self.agent.agent_name
            )
            session.add(agent_output)
            session.commit()
            session.refresh(agent_output)
            return agent_output
