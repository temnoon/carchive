# src/rendering/message_renderer.py
