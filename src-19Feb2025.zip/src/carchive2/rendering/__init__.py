# src/rendering/__init__.py
