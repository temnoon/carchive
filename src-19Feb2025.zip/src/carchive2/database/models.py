# src/carchive2/database/models.py
"""
SQLAlchemy ORM models (tables). Avoid using the word "metadata" to prevent collisions.
"""

import uuid
from sqlalchemy import Column, String, DateTime, ForeignKey, Text, JSON, Integer
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.sql import func

# If using pgvector, you import from pgvector.sqlalchemy
from pgvector.sqlalchemy import Vector

Base = declarative_base()

class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    meta_info = Column(JSON, nullable=True)

    messages = relationship("Message", back_populates="conversation")

class Message(Base):
    __tablename__ = "messages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"))
    content = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    meta_info = Column(JSON, nullable=True)
    media_id = Column(UUID(as_uuid=True), ForeignKey("media.id"), nullable=True)

    conversation = relationship("Conversation", back_populates="messages")
    chunks = relationship("Chunk", back_populates="message")
    media = relationship("Media", back_populates="messages")

class Chunk(Base):
    __tablename__ = "chunks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    message_id = Column(UUID(as_uuid=True), ForeignKey("messages.id"))
    content = Column(Text, nullable=True)
    position = Column(Integer, default=0)
    meta_info = Column(JSON, nullable=True)

    message = relationship("Message", back_populates="chunks")

class Embedding(Base):
    __tablename__ = "embeddings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    model_name = Column(String, nullable=False)
    model_version = Column(String, nullable=True)
    dimensions = Column(Integer, nullable=False)
    vector = Column(Vector(768))  # Example dimension
    parent_message_id = Column(UUID(as_uuid=True), ForeignKey("messages.id"), nullable=True)
    parent_chunk_id = Column(UUID(as_uuid=True), ForeignKey("chunks.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    meta_info = Column(JSON, nullable=True)

class Collection(Base):
    __tablename__ = "collections"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    meta_info = Column(JSON, nullable=True)

    items = relationship("CollectionItem", back_populates="collection")

class CollectionItem(Base):
    __tablename__ = "collection_items"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    collection_id = Column(UUID(as_uuid=True), ForeignKey("collections.id"))
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=True)
    message_id = Column(UUID(as_uuid=True), ForeignKey("messages.id"), nullable=True)
    chunk_id = Column(UUID(as_uuid=True), ForeignKey("chunks.id"), nullable=True)
    meta_info = Column(JSON, nullable=True)

    collection = relationship("Collection", back_populates="items")
    # Optionally create relationships to Conversation, Message, Chunk if needed

class AgentOutput(Base):
    __tablename__ = 'agent_outputs'

    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    target_type = Column(String, nullable=False)  # 'message', 'conversation', 'chunk'
    target_id = Column(PG_UUID(as_uuid=True), nullable=False)
    output_type = Column(String, nullable=False)  # 'summary', 'rating', 'review', etc.
    content = Column(Text, nullable=False)
    agent_name = Column(String, nullable=False)  # e.g., 'llama3.2'
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    # Optionally, add relationships if needed
    # For example, relationship to Message, Conversation, or Chunk

class Media(Base):
    __tablename__ = "media"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    file_path = Column(String, nullable=False)
    media_type = Column(String, nullable=False)  # E.g., 'image', 'pdf', 'audio'
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    messages = relationship("Message", back_populates="media")
    # commenting out chunks relative to media for now.
    # chunks = relationship("Chunk", back_populates="media")
